import React, { useState,useEffect } from 'react'
import lg from 'local-storage'
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import data from './data'
import Navbar from './components/Navbar'
import Allproducts from './components/Allproducts'
import Junaid from './components/Junaid';
import Cart from './components/Cart';
import Home from './components/Home';
import Header from './components/Header';
import Mail from './components/Mail';
import Fragrances from './components/Fragrances'
import Footer from './components/Footer';
import Men from './components/Men';
import Febric from './components/Febric';
import Shop from './components/Shop';
import items from './items';
import Women from './components/Women';
import Checkout from './components/Checkout';
import Bfashion from './components/Bfashion';
import Makeup from './components/Makeup';


function App() {
 const {item} = items
  const {products,} = data;


 
const [cartItems ,setCartItems] = useState([]);
const onAdd = (product) =>{
  const exist = cartItems.find ((x)=>x.id === product.id);
if (exist){
  setCartItems(
    cartItems.map((x)=>x.id ===product.id ? {...exist, qty:exist.qty +1} : x)
  );
  console.log(cartItems)
}else{
  setCartItems([...cartItems,{...product ,qty:1}]);
console.log(cartItems)
}

}
useEffect(() => {
  // storing input name
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
}, [cartItems]);


const onRemove = (product)=>{
  const exist = cartItems.find((x)=>x.id ===product.id)
  if (exist.qty === 1){
    setCartItems(
      cartItems.filter((x)=>x.id !== product.id)
    )
  }else{
    setCartItems(
      cartItems.map((x)=>x.id===product.id ? {...exist,qty:exist.qty -1} : x)
    )
  }
}



  return (
    <div>
      
      <Router>
     
      <Navbar productsCount = {cartItems.length} />
      <Junaid />
      <Header />
      <Switch>
        

      <Route  path = '/' exact component = {Home} />
      <Route  path = '/Home' exact component = {Home}    />
      <Route path = '/Men' exact component = {Men} />
      <Route path = '/Women' exact component = {Women} />
      {/* <Route path = '/Checkout' exact component = {Checkout} /> */}
      <Route  path = '/Fragrances' exact component = {Fragrances} />
      <Route  path = '/Bfashion' exact component = {Bfashion} />
      <Route  path = '/Makeup' exact component = {Makeup} />
        <Allproducts exact path = '/Febric' products = {products} addProduct = {onAdd} />
        <Cart path="/cart" cartItems={cartItems} onAdd ={onAdd} onRemove = {onRemove}  />
        <Route path = '/Febric' exact component = {Febric} />
        <Shop exact path = '/Shop' item = {item} additem = {onAdd} />
        <Checkout path="/Checkout" cartItems={cartItems} onAdd ={onAdd} onRemove = {onRemove}  />
      </Switch>

      <Mail />
      <Footer />
     
      
      </Router>
    </div>
  )
}

export default App
