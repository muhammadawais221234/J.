import React from "react";


function Allproducts (props){
  const {products ,addProduct} = props
console.log (props)
return (
  <div>
     <div className="container-fluid">
            {/* <h1 className="text-center display-3">Welcome To Ecommerce App</h1>
            <img src="/pics/banner.jpg" style={{ width:'100%' }} />
            <h1 className="text-center display-3">List of All Products</h1> */}
            <div className="row">
                {
                   products.map((prod) => (
                        <div class="col-md-4 py-2">
                        <div class="card ">
                        <a href = 'Shop'><img class="card-img-top  "  src={prod.image} style={{ width:'420px', height:'450px' }} /></a>
                        <div class="card-body">
                          <a className='text-dark' href='Shop'><h5 class="card-title">{prod.name}</h5></a>
                          <p class="card-text">{prod.price}</p>
                          <button onClick={() => addProduct(prod)} class="btn btn-primary">Add To Cart</button>
                        </div>
                        </div>
                      </div>
                    ))
                }
            </div>
        </div>
  </div>
)
}


export default Allproducts;