
function Arival (){
    return (
        <div>
            <h3 className ='text-center'> <a class=" text-dark" href="#">NEW ARRIVALS</a></h3>
            <div className ='text-center'>
                <h1>Boys and Girls</h1>
            </div>
        </div>
    )
    
    }
    
    
    export default Arival;