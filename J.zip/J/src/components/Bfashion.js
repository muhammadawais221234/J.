
import React  from "react"
import {Link} from 'react-router-dom'
function Bfashion (){
return (
<div>
 
 <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<a href=''><img src="https://www.junaidjamshed.com/media/catalog/product/2/1/21-6008_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-70" height ='500' alt="..." /></a>
<h6>Shirt</h6>
<h4><a href='' className ='text-dark'>Shop now</a></h4>
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<a href=''><img src="https://www.junaidjamshed.com/media/catalog/product/2/1/21-5003_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-70" height ='500' alt="..." /></a>
<h6>Shirt</h6>
<h4><a href='' className ='text-dark'>Shop now</a></h4>
</div>

   </div>
 </div>



 <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/catalog/product/3/8/38387_3_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-70" height ='500' alt="..." />
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/catalog/product/j/c/jck-41073_1_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-70" height ='500' alt="..." />
</div>

   </div>
 </div>

  



</div>
        






)
}


export default Bfashion;