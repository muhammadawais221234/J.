import 'bootstrap/dist/css/bootstrap.min.css'
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import './Header.css'
function Boys (){
    return (
    <div>
    <div className='container py-5'>
        <div className='row d-flex justify-content-center'> 
           <div className='col-md-4  py-2'>
            <img class="d-block w-100" height='450' src="https://www.junaidjamshed.com/media/wysiwyg/w25.jpg" alt="" /><h4 className='text-center'>Kurta</h4>
            <img class="d-block w-100" height='450' src="https://www.junaidjamshed.com/media/wysiwyg/w26.jpg" alt="" /><h4 className='text-center'>Waistcoat</h4>
           </div>
            <div className='col-md-6 py-2'>
            <a href='Febric'><img class="d-block w-100" src="https://www.junaidjamshed.com/media/wysiwyg/w27.jpg" height='935' alt="" /></a><h3><a href='Febric' className='text-dark text-decoration-none'>Kameez shalwar</a></h3>
            </div>
           
        </div>
    </div>




    
    </div>
    
    )
    
    }
    
    export default Boys;
    