import React from "react";
import {Link} from 'react-router-dom'

function Cards(props){
return (
    <>
        <div className="card">
 <img src= {props.src} className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title"><a href='\\' className='text-dark'>{props.title}</a></h5>
    <p className="card-text">{props.text}</p>
    <h5 className='Card-subtitle'>{props.subtitle}</h5>
  

    <a className="btn btn-outline-primary text-dark">ADD TO BAG</a>
  </div>
</div>

    </>
)
};




export default Cards;








