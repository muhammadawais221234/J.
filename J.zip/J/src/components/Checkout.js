import './Header.css'

import React, { useState,useEffect } from 'react'
import {Link} from 'react-router-dom'
function Checkout (props){
    const [name ,setName] = useState('')
    useEffect(() => {
        // storing input name
        localStorage.setItem("name", JSON.stringify(name));
      }, [name]);
     const myName =localStorage.getItem('name')



    const {cartItems,onAdd,onRemove} = props;
    const itemPrice = cartItems.reduce ((a ,c)=> a+c.qty * c.price,0)
    const taxPrice = itemPrice * 0.01;
    const shippingPrice = itemPrice > 2000 ? 0 : 200
    const totalPrice = itemPrice +taxPrice +shippingPrice
    return(
        <div>
          <div className='container-fluid px-5'>
              
          <div className='text-center'><h1 >SECURE CHECKOUT</h1>
            
            </div>
            <div>
            <div className='d-flex justify-content-center'> <h3 className=''>Shipping</h3><p className='px-5 py-2'>Review & Payments</p></div>
            
            </div>
              <div className='row'>
                  <div className='col-md-7'>
                  
          
           
                <div className='row'>

                    
                    
                    <div className='col-md-12 py-5 '>

<h2>Shipping Address</h2>

<div> 
                       <form className='py-3'>
                       <div class="form-group">
    <div className='d-flex justify-content-between'><label for="exampleInputEmail1">Contact information<span class='text-danger'>*</span></label><p className=''> Already have an account?Log in</p></div>
    <input type="email" class="form-control px-1" width='1cm'  aria-describedby="emailHelp" placeholder='Email' /></div>
    <p>Email me with news and offers</p>
                       </form>
                       
                       </div>

                       <h5>Shipping address</h5>
                       <div className='d-flex justify-content-between'>
                      
                       <input type="text" value ={name} onChange={(e)=>setName(e.target.value)}  class="form-control "  aria-describedby="emailHelp" placeholder='First Name' />
                       <input type ='submit' onSubmit = {(myName)}></input>
                      
                      
                       <input type="text" class="form-control mx-2"  aria-describedby="emailHelp" placeholder='Last Name' />

                       </div>
                       <div className='py-3'><input type="text" class="form-control "  aria-describedby="emailHelp" placeholder='Address' /></div>
                       <div className='py-3'><input type="text" class="form-control "  aria-describedby="emailHelp" placeholder='Apartment,Suit etc (Optional)' /></div>
                       <div className='py-3'><input type="text" class="form-control "  aria-describedby="emailHelp" placeholder='City' /></div>
                       <div className='d-flex justify-content-between'>
                       <input type="text" class="form-control "  aria-describedby="emailHelp" placeholder='Country , region' />
                       <input type="text" class="form-control mx-2"  aria-describedby="emailHelp" placeholder='Postal code' />

                       </div>

                       <div className='py-3'><input type="text" class="form-control "  aria-describedby="emailHelp" placeholder='Phone' /></div>
                       <p>Save this information for next time</p>
                       <div className='d-flex justify-content-between'>
                           <Link className='text-dark' to='Cart'> Return to cart</Link>
                           <Link className='' to ='Checkout'><button   className='btn btn-outline-primary' type='submit'>
                           Continue to shipping
                
                </button></Link>

                       </div>


                    </div>
                  
                </div>

            </div>
                 
                  <div className='col-md-5 bg px-5 py-5 div-1 text-white'>
                      <div className=' '>
                          <h5 className='text-center'>Order Summary</h5>
                         <hr />
                         <table className ='table tabl-bordered'>
             <tr>
                    
                    
                    <th className='text-white'>Prodduct Price</th>
                    <th className='text-white'>Quantity</th>
                    <th className='text-white'>Image</th>
                    
                </tr>
                {
                   cartItems.map((item)=>(
                       <tr>
                                
                            
                            <td className='text-white'>{item.price}</td>
                            <td className='text-white'>{item.qty}</td>
                            <td className='text-white'><img src={item.image} style={{ width:'100px', height:'100px' }} /></td>
                           
                       </tr>
                   ))
                        
                    
                }
             </table>
             <small>Actual Price: Rs.{itemPrice} </small>
            <br/>
            <small>Fix Shipping Price: Rs.{shippingPrice} </small>
            <br />
            <small>Tax Applied: Rs.{taxPrice} </small>
            <p className="lead">Total Price: Rs.{totalPrice} </p>
                        
                      </div>
                      









                  </div> </div>
              </div>
          </div>

        
    )
}

export default Checkout;

