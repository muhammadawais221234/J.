
function Dress (){
    return (
        <div>
     <div className='container py-5'>
         <div className='row'>
             <div className='col-md-6 py-3 '>
             <img  src="https://www.junaidjamshed.com/media/catalog/product/j/w/jwt-21-3503_3_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-100" height ='600' alt="..." /></div>
           
               <div className='col-md-2 py-3'>
               <img  src="https://www.junaidjamshed.com/media/catalog/product/3/5/35826_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-100" height ='300' alt="..." /> 
            
               </div>
               <div className='col-md-2  py-3'>
               <img  src="https://www.junaidjamshed.com/media/catalog/product/3/8/38429_3_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755" class="d-block w-100" height ='300' alt="..." /> 
            
               </div>
               <div className='col-md-2  py-3'>
               <img  src="https://www.junaidjamshed.com/media/catalog/product/3/7/37535_1_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=560&width=436" class="d-block w-100" height ='300' alt="..." /> 
               </div>
               </div>
         </div>
 </div>
    )
    
    }
    
    export default Dress;