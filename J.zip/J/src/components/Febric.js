
function Febric (){
    
   
    return (
       
        <div>
          
        </div>
    )
}


export default Febric