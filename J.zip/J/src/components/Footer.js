

function Footer (){
    return (
        <div>
            <div className ='container'>
                <div className='row'>
                    <div className='col-4'>
                        <h3>Need help?</h3><br />
                        <h6>+92 21 111 112 111 (9am - 10pm , Mon - Sat, Sunday 11am - 08pm)</h6>
                        <p>eshop@junaidjamshed.com</p>
                    </div>

                    <div className='col-4'>
                        <h3>CUSTOMER SERVICE</h3>
                        <h6>Delivery & Orders</h6>
                        <h6>Returns & Exchanges</h6>
                        <h6>Terms & Conditions</h6>
                        <h6>Privacy Policy</h6>
                    </div>

                    <div className='col-4'>
                        <h3>Company</h3>
                        <h6>About us</h6>
                        <h6>Careers</h6>
                        <h6>Store locator</h6>
                    </div>
                </div>
            </div>

        </div>
    )
}


export default Footer;













