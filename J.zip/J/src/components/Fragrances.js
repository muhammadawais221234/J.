import Cards from './Cards'
import React from 'react';
import {Link } from 'react-router-dom';


function Fragrances (){
    return (
        <div>
        <div className='container py-5'>
            <div className='row '>
                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'>
                    <Cards title ='Quick shop' subtitle ='PKR13,800.00' text='DEFENDER POUR HOMME' src='https://www.junaidjamshed.com/media/catalog/product/w/a/warrior_pour_homme_1_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' />
                </div>

                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR6,500.00' text='DEFENDER POUR HOMME' src='https://www.junaidjamshed.com/media/catalog/product/2/_/2_9_4.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR2,100.00' text='ULTRA' src='https://www.junaidjamshed.com/media/catalog/product/u/l/ultra_1__1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            </div>

            <div className='row'>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR2,100.00' text='BLOSSOM' src='https://www.junaidjamshed.com/media/catalog/product/b/l/blossom_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR3,800.00' text='JANAN GOLD' src='https://www.junaidjamshed.com/media/catalog/product/e/x/exclusive_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR13,800.00' text='EDGE' src='https://www.junaidjamshed.com/media/catalog/product/e/d/edge_2__1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            </div>
        </div>

    </div>
    )
}



export default Fragrances;