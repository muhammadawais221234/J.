
import './Header.css'


function Girls (){
    return (
        <div>
<div className='container py-5 '>
        <div className='row d-flex justify-content-center'>
        <div className='col-md-6 py-2'>
            <img class="d-block w-100" height='935' src="https://www.junaidjamshed.com/media/wysiwyg/w20.jpg" alt="" /><h4 className='text-center'>Unstitched</h4>
            </div> 
            <div className='col-md-4  py-2'>
            <img class="d-block w-100"  height='450' src="https://www.junaidjamshed.com/media/wysiwyg/ku1.jpg" alt="" /><h4 className='text-center'>Kurti</h4>
            <img class="d-block w-100"  height='450' src="https://www.junaidjamshed.com/media/wysiwyg/w22.jpg" alt="" /><h4 className='text-center'>Stitched</h4>
           </div>
       
           
        </div>
    </div>




















        </div>
    )











 }


export default Girls;

