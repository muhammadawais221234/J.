import React from 'react'
import {Link} from 'react-router-dom'
import  './Header.css'

function Header (){
return (
    <div className=''>
        <nav className="navbar my-nav navbar-expand-lg navbar-dark navbar-dark  ">
  <Link className="navbar-brand text-dark" to="Home"><h3>J.</h3></Link>
  <button className="navbar-toggler bg-dark text-dark" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mx-auto">
      <li className="nav-item active">
        <Link  className="nav-link text-dark" to="Men">Men <span className="sr-only">(current)</span></Link>
      </li>
      <li className="nav-item">
        <Link className="nav-link text-dark " to="Women">Women</Link>
      </li>
      <li className="nav-item dropdown ">
        <Link className="nav-link  dropdown-toggle text-dark" to="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
          New Arival
        </Link>
        <div className="dropdown-menu bg-dark text-dark" aria-labelledby="navbarDropdown">
          <Link className="dropdown-item bg-dark text-white" to="action">Top</Link>
          <a className="dropdown-item bg-dark text-white" to="another action">Bottom</a>
          <div className="dropdown-divider "></div>
          <Link className="dropdown-item bg-dark text-white" to="something else here">Bags</Link>
        </div>
      </li>
      <li className="nav-item">
        <Link className="nav-link text-dark " to ='Fragrances'>Fragrances</Link>
      </li>
      <li className="nav-item">
        <Link className="nav-link text-dark " to ='Bfashion'>BOYS & GIRLS</Link>
      </li>
      <li className="nav-item">
        <Link className="nav-link text-dark " to ='Makeup'>MAKEUP</Link>
      </li>
    
    </ul>
    {/* <form className="form-inline my-2 my-lg-0">
      <input className="form-control mr-sm-2 text-dark" type="search" placeholder="Search" aria-label="Search" />
      <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> */}
  </div>
</nav>
    </div>
)

}

export default Header;



