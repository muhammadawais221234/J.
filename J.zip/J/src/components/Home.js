import Slider from "./Slider";
import Girls from "./Girls";
import Boys from "./Boys";
import Sanitizer from "./Sanitizer";
import Arival from "./Arival";
import Dress from "./Dress";
import data from "../data";

function Home (){ 
    
console.log(localStorage.getItem('cartItems'))
  
    return (
        <div>
            <Slider />
            <Boys />
            <Girls />
            
            <Sanitizer />
            <Arival />
            <Dress />
        </div>
    )
}


export default Home;