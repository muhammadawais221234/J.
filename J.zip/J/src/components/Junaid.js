import React from "react";
import {Link} from 'react-router-dom'
function Junaid (){
    return (
        <div className ='text-center'>
            <h1 className=''><Link className='text-dark text-decoration-none' to='Home'>J.</Link></h1>
        </div>
    )
}


export default Junaid;
