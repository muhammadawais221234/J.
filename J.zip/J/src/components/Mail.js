import './Mail.css'
function Mail (){
    return (
        <div className =''>
     <div className='container'>
       <div className='row'>
         <div className='col-md-12 col-sm-12'>
         <div class="card text-center px-5 My-div">
  
  <div class="card-body">
    <h5 class="card-title text-white">BE THE FIRST</h5>
    <p class="card-text text-white">New arrivals. Exclusive previews. First access to sales. Sign up to stay in the know.</p>
    <form class="form-inline text-center d-flex justify-content-center my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Enter your email address" aria-label="Search" />
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Sign up</button>
    </form>
  </div>
  
</div>
         </div>
       </div>
     </div>

        </div>
    )
}


export default Mail;