import Cards from './Cards'
import React from 'react';
import {Link } from 'react-router-dom';


function Makeup (){
    return (
        <div>
        <div className='container py-5'>
            <div className='row '>
                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'>
                    <Cards title ='Quick shop' subtitle ='PKR1,190' text='ULTRA BLACK EYELINER' src='https://www.junaidjamshed.com/media/catalog/product/a/u/automatic-highlighter-pencil-j..jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' />
                </div>

                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR1,190' text='ULTRA VOLUME MASCARA' src='https://www.junaidjamshed.com/media/catalog/product/i/n/intense-eye-look-main_1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
                <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR990.00' text='ULTRA BLACK DIPLINER' src='https://www.junaidjamshed.com/media/catalog/product/p/e/perfect_lash_mascara.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            </div>

            <div className='row'>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR990.00' text='BROW ADDICT TINT AND SHAPING GEL' src='https://www.junaidjamshed.com/media/catalog/product/u/l/ultra_black_eyeliner_1_1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR790.00' text='LOVE AT FIRST SIGHT EYESHADOW' src='https://www.junaidjamshed.com/media/catalog/product/u/l/ultra_volume.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            <div className ='col-lg-4 col-md-8 col-sm-12 py-2'><Cards title ='Quick shop' subtitle ='PKR1,490' text='BAKED HIGHLIGHTER' src='https://www.junaidjamshed.com/media/catalog/product/u/l/ultra_black_dipliner_1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=755&width=589&canvas=589:755' /></div>
            </div>
        </div>

    </div>
    )
}



export default Makeup;