import React  from "react"
import {Link} from 'react-router-dom'
function Men (){
 
return (
<div>
 
 <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<a href='Febric'><img src="https://www.junaidjamshed.com/media/wysiwyg/KAMEEZ_SHALWAR_2.jpg" class="d-block w-70" height ='500' alt="..." /></a>
<h6>Kurta</h6>
<h4><a href='Febric' className ='text-dark'>Shop now</a></h4>
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<a href='Buy'><img src="https://www.junaidjamshed.com/media/wysiwyg/KURTA_1_1.jpg" class="d-block w-70" height ='500' alt="..." /></a>
<h6>Kurta</h6>
<h4><a href='Buy' className ='text-dark'>Shop now</a></h4>
</div>

   </div>
 </div>



 <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/kid_boys_12.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/teen_boys_21.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

   </div>
 </div>

  



</div>
        






)
}


export default Men;

