import React from 'react'
import { Link } from "react-router-dom";
import './Navbar.css'

function Navbar(props) {

     return (
 

<div>
<ul class="nav">
<li class="nav-item">
<Link className="nav-link active text-dark" to="Home">WELCOME TO J.</Link>
</li>
<li class="nav-item">
<Link className="nav-link text-dark" to="#">SIGN IN</Link>
</li>
<img src="https://www.junaidjamshed.com/static/version1636371383/frontend/Rltsquare/junaidjamshed/en_US/Magento_Theme/images/pak-flag.png" className="d-block py-2" alt="..." width='30' height='40' />

{/* <li class="nav- px-3">
<Link class="navbar-brand text-dark" to="Ecommerce">Ecommerce</Link>
</li> */}

{/* <li class="nav-item">
<Link class="nav-link text-dark navbar-brand text-decoration-none " to="/cart"><i class="fas fa-shopping-basket"></i> {' '}
<button className="badge bg-dark text-white">{props.productsCount}</button>
</Link>
</li> */}





</ul>

<div className='d-flex justify-content-end'>


<Link className="nav-link text-dark navbar-brand text-decoration-none  " to="/cart" ><i height='400' width='400' className="fas fa-shopping-basket"></i> {' '}

<button height='10px' height='10px'  className="badge bg-dark text-white">{props.productsCount}</button>
</Link>
</div>





</div>
    )
}

export default Navbar
