

function Sanitizer (){
    return (
        <div>
            
     <div className ='container-fluid'>
         <div className ='row'>
             <div className ='col-12'>
             <img src="https://www.junaidjamshed.com/media/wysiwyg/012.jpg" class="d-block w-100" alt="..."></img>
             </div>
            
           
         </div>
     </div>
   
    
        </div>
    )
}

export default Sanitizer