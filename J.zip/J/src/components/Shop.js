import React, { useState, useEffect } from 'react';

// import CursorZoom from 'react-cursor-zoom';

const White1 = 'https://www.junaidjamshed.com/media/catalog/product/4/2/42270_1_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=560&width=436'
const White2 ='https://www.junaidjamshed.com/media/catalog/product/4/2/42270_2_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=560&width=436'
const White3 = 'https://www.junaidjamshed.com/media/catalog/product/4/2/42270_3_.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=560&width=436'
const Shirts = {White1,White2,White3}

function Shop (props){
    const {item,additem} = props
    const [selected , setSelected] = useState(Shirts.White1)
    
return (
<>
<div className='container'><div className='row'>
    <div className='col-lg-6'>
<div className='col-6 py-3'>
    
 {/* <CursorZoom
                image={{
                     src: (selected),
                     width: 400,
                     height: 500
                 }}
                 zoomImage={{
                     src: (selected),
                   width: 400,
                     height: 500
                 }}
                 cursorOffset={{ x: 100, y: -40 }}
             /> */}
    <img src = {selected} />
</div>

<div className='container'>
    <div className='row'>
        <div className='col-md-3'>
    <image onClick = {()=> setSelected(Shirts.White1)}><div className='col-lg-4 py-2 col-sm-12'>
    <img height='150' width='100' src = {Shirts.White1} />
</div></image></div>
<div className='col-md-3'>
<image onClick = {()=> setSelected(Shirts.White2)}><div className='col-lg-4 py-2 col-sm-12'>
    <img height='150' width='100' src = {Shirts.White2} />
</div></image></div>
<div className='col-md-3'>
<image onClick = {()=> setSelected(Shirts.White3)}><div className='col-lg-4 py-2 col-sm-12'>
    <img height='150' width='100' src = {Shirts.White3} />
</div></image></div>
    </div>
</div>

</div>
<div className='col-lg-6 py-2'>
    <h5>OFF WHITE BLENDED KAMEEZ SHALWAR | JJKS-A-42270</h5>
    <p className='text-start'>SKU # J-GM147932</p>
    <p>IN STOCK</p>
    <p><a className='text-dark' href ='##'>BE THE FIRST TO REVIEW THIS PRODUCT
</a></p>

<h2>PKR6,190
</h2><hr />
<div>
<button type="button" class="btn btn-outline-secondary">S</button>
<button type="button" class="btn btn-outline-secondary ">M</button>
<button type="button" class="btn btn-outline-secondary">L</button>
<button type="button" class="btn btn-outline-secondary">Xl</button>
</div>

<div className='py-5 '>
{

item.map((prod) => (
               
                          <button onClick={() => additem(prod)} class="btn btn-dark px-5">Add To Cart</button>
                       
                      
                    ))
                }

</div>
</div>


</div></div>

    
  
    </>
)

}











export default Shop;

