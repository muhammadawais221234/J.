import React from "react";
import {Link} from 'react-router-dom'

function Women (){
return (
    <div>
        
        <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/kid_girls_22.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/teen_girls_17.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

   </div>
 </div>



 <div className ='container py-5'>
   <div className ='row'>
<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/unstitched_43.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

<div className ='col-lg-6 col-md-12 col-sm-12 py-2'>
<img src="https://www.junaidjamshed.com/media/wysiwyg/stitched_28.jpg" class="d-block w-70" height ='500' alt="..." />
</div>

   </div>
 </div>


    </div>
)

}


export default Women;





