const data = {
    products : [
      {
         id: '1',
         name: 'OFF WHITE BLENDED KAMEEZ SHALWAR | JJKS-A-42270',
         price: 6190,
         image: '/pics/image1.jpg' 
      },
     
      {
        id: '2',
        name: 'COFFEE COTTON KAMEEZ SHALWAR | JJKS-A-',
        price: 4690,
        image: '/pics/image2.jpg' 
     },
     {
        id: '3',
        name: 'TEXTURED GREEN COTTON KURTA TROUSER |',
        price: 5890,
        image: '/pics/image3.jpg' 
     },
     {
        id: '4',
        name: 'STONE BLUE COTTON KAMEEZ SHALWAR | JJKS-',
        price: 5890,
        image: '/pics/image4.jpg' 
     },
     {
      id: '5',
      name: 'LIGHT BROWN COTTON KAMEEZ SHALWAR |',
      price: 4990,
      image: '/pics/image5.jpg' 
   },
   {
      id: '6',
      name: 'MAROON BLENDED KAMEEZ SHALWAR | JJKS-A-',
      price: 6290,
      image: '/pics/image6.jpg' 
   }
    ]
}
export default data;