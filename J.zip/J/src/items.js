const items = {
    item : [
      {
         id: '1',
         name: 'OFF WHITE BLENDED KAMEEZ SHALWAR | JJKS-A-42270',
         price: 6190,
         image: '/pics/image1.jpg' 
      },
    ]}


    export default items;